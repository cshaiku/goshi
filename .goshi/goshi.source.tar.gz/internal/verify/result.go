package verify

type Result struct {
	Passed   bool
	Failures []string
}
