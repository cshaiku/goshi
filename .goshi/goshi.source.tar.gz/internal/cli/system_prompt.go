package cli

import "github.com/cshaiku/goshi/internal/llm"

type Runtime struct {
	SystemPrompt *llm.SystemPrompt
}
