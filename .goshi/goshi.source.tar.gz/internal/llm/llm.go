package llm

// This file intentionally left blank.
// The LLM client implementation lives in client.go.
